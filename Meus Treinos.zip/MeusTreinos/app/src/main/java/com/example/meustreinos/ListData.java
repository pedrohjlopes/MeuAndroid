package com.example.meustreinos;

public class ListData {

    String name,time;
    int  exercicios, desc;
    int image;

    public ListData(String name, int desc, int image, int exercicios, String time) {
        this.name = name;
        this.desc = desc;
        this.image = image;
        this.exercicios = exercicios;
        this.time = time;
    }
}

