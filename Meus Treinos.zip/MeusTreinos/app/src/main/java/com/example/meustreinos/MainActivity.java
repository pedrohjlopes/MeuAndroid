package com.example.meustreinos;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

     ActivityMainBinding binding;
     ListAdapter listAdapter;
     ArrayList<ListData> dataArrayList = new ArrayList<>();
     ListData listData;

     @Override
     protected void onCreate(Bundle saveInstanceState){
          super.onCreate(saveInstanceState);
          binding = ActivityMainBinding.inflate(getLayoutInflater());
          setContentView(binding.getRoot());
     int[] images = {R.drawable.costas, R.drawable.pernas, R.drawable.ombros_trapezio};
     int[] desc = {R.string.tr
     }

}
